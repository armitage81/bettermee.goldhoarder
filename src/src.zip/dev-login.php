<?php
if (getenv('APP_ENV') !== 'development') {
    http_response_code(403);
    exit('Not available in production.');
}

session_name('BETTERMEE_SESSID');
session_set_cookie_params(['path' => '/']);
session_start();

$_SESSION['user_id'] = 1;
$_SESSION['user_email'] = 'dev@example.com';
$_SESSION['user_role'] = 'admin';

header('Location: index.php');
exit;
